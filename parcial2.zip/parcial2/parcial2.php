<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Calculadora de Factoriales</title>
</head>
<body>
    <h1>Calculadora de Factoriales</h1>
    <form action="procesar.php" method="post">
        <label for="numero">Ingrese un número:</label>
        <input type="number" name="numero" required>
        <button type="submit">Calcular Factorial</button>
    </form>
</body>
</html>
