<?php
class miotraclase {
public function __construct() {
echo "Mi segunda Clase ha sido agregada!!! <br>";
}
}
?>